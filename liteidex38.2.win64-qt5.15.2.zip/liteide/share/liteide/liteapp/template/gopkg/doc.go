// $ROOT$ project doc.go

/*
$ROOT$ document
*/
package $ROOT$
