<!-- Forever -->

Forever
=======

## 道德经
道可道，非常道。名可名，非常名。
无名天地之始；有名万物之母。

## 2018.02.14 
**三十功名尘与土，八千里路云和月。**

## 天行健
**天行健，君子以自强不息。地势坤，君子以厚德载物。**

![](images/liteide.png)

## logo 

![](images/liteide400.png)

## @_@
佛祖问阿难：你有多喜欢这少女? 阿难说：我愿化身石桥，受五百年风吹，五百年日晒，五百年雨打，但求此少女从桥上走过。


## with you

![](images/flamingo.png)

## forever
![](images/forever.png)

