Kate Default Styles
===================

**kate standard:**

	dsNormal
	dsVisualWhitespace
	dsKeyword
	dsDataType
	dsDecimal
	dsBaseN
	dsFloat
	dsChar
	dsString
	dsComment
	dsAlert
	dsError
	dsFunction
	dsRegionMarker
	dsOthers

**liteide extension:**

	dsSymbol
	dsBuiltinFunc
	dsPredeclared
	dsFuncDecl
	dsPlaceholder
	dsToDo
